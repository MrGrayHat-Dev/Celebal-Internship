function first(array, n) {
  if (!Array.isArray(array)) return [];
  if (n == null) return array[0];
  if (n < 0) return [];
  return array.slice(0, n);
}

// Test Data
console.log(first([7, 9, 0, -2]));     
console.log(first([], 3));             
console.log(first([7, 9, 0, -2], 3));   
console.log(first([7, 9, 0, -2], 6));   
console.log(first([7, 9, 0, -2], -3));  
